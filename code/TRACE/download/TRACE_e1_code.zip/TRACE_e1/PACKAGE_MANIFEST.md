# TRACE E1 Demo Package Manifest

## Package Root
`/Users/zack/Desktop/Code/trace-e1-demo-trace-only`

## Included
- `src/trace/`
- `scripts/run_trace_e1.py`
- `scripts/check_trace_repro.py`
- `configs/trace_e1.yaml`
- `data/SMRTnet_main_repro.csv`
- `data/splits/smrt_5fold_seed7.csv`
- `golden/trace_e1_golden_summary.csv`
- `golden/trace_e1_golden_folds.csv`
- `outputs/run_demo_001/` (TRACE-only run)
- `README.md`
- `requirements.txt`
- `environment.yml`
- `LICENSE`
- `CITATION.cff`

## Excluded
- Comparator method code and comparator result tables
- Multi-dataset and target-fit scripts/outputs

## Validation Snapshot
- Repro check: `PASS` (`tol=1e-12`)
- Comparator keyword scan: no hits for
  `existing4|frozen|baseline|RNAmigos2|RNAsmol|sChemNET|SMRTnet_struct|comparator`

## Run Commands
```bash
python /Users/zack/Desktop/Code/trace-e1-demo-trace-only/scripts/run_trace_e1.py \
  --config /Users/zack/Desktop/Code/trace-e1-demo-trace-only/configs/trace_e1.yaml \
  --out /Users/zack/Desktop/Code/trace-e1-demo-trace-only/outputs/run_demo_001

python /Users/zack/Desktop/Code/trace-e1-demo-trace-only/scripts/check_trace_repro.py \
  --run /Users/zack/Desktop/Code/trace-e1-demo-trace-only/outputs/run_demo_001 \
  --golden /Users/zack/Desktop/Code/trace-e1-demo-trace-only/golden/trace_e1_golden_summary.csv \
  --tol 1e-12
```

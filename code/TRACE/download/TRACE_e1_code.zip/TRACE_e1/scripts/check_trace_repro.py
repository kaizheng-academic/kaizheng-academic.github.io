#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description='Check TRACE E1 reproducibility against golden summary.')
    p.add_argument('--run', required=True, help='path to run output directory (contains summary/trace_e1_summary.csv)')
    p.add_argument('--golden', default='golden/trace_e1_golden_summary.csv')
    p.add_argument('--tol', type=float, default=1e-12)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    run_dir = Path(args.run).resolve()
    root = run_dir.parents[1] if run_dir.name.startswith('run_') else Path(__file__).resolve().parents[1]

    pred_path = run_dir / 'summary' / 'trace_e1_summary.csv'
    if not pred_path.exists():
        raise RuntimeError(f'missing run summary: {pred_path}')

    golden_path = Path(args.golden)
    if not golden_path.is_absolute():
        golden_path = (Path(__file__).resolve().parents[1] / golden_path).resolve()

    run = pd.read_csv(pred_path)
    gold = pd.read_csv(golden_path)

    cols = ['AUROC_mean', 'AUROC_std', 'AUPRC_mean', 'AUPRC_std', 'ECE_mean', 'ECE_std', 'Brier_mean', 'Brier_std']
    deltas = {c: float(abs(run[c].iloc[0] - gold[c].iloc[0])) for c in cols}
    ok = all(v <= float(args.tol) for v in deltas.values())

    report = {
        'run_summary': str(pred_path),
        'golden_summary': str(golden_path),
        'tol': float(args.tol),
        'max_abs_delta': deltas,
        'pass': bool(ok),
    }
    out = run_dir / 'checks' / 'repro_check.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')

    print('PASS' if ok else 'FAIL')
    print(json.dumps(report, indent=2, ensure_ascii=False))
    if not ok:
        raise SystemExit(2)


if __name__ == '__main__':
    main()

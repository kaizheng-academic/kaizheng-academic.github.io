#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import sys
import time
import json
from pathlib import Path

import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src'
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from trace.cv import load_data, load_split, validate_split
from trace.features import fit_transform_features
from trace.io import file_sha256, git_commit_or_na, obj_sha256, write_json
from trace.metrics import brier, ece_score, safe_auprc, safe_auroc
from trace.model import TrainCfg, predict_trace, set_global_seed, train_trace


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description='Run TRACE E1 5-fold reproduction.')
    p.add_argument('--config', default=str(ROOT / 'configs' / 'trace_e1.yaml'))
    p.add_argument('--output-dir', default='')
    p.add_argument('--out', default='')
    p.add_argument('--data-root', default='')
    p.add_argument('--golden', default=str(ROOT / 'golden' / 'trace_e1_golden_summary.csv'))
    p.add_argument('--tol', type=float, default=0.005)
    return p.parse_args()


def read_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding='utf-8')) or {}


def main() -> None:
    args = parse_args()
    cfg_path = Path(args.config).resolve()
    cfg = read_yaml(cfg_path)

    seed = int(cfg.get('train', {}).get('seed', cfg.get('seed', 7)))
    n_splits = int(cfg.get('train', {}).get('n_splits', cfg.get('n_splits', 5)))
    if seed != 7:
        raise RuntimeError(f'seed must be 7, got {seed}')

    out_dir = Path(args.output_dir or args.out or cfg.get('output', {}).get('dir', ROOT / 'outputs' / 'run_latest')).resolve()
    raw_dir = out_dir / 'raw'
    summary_dir = out_dir / 'summary'
    checks_dir = out_dir / 'checks'
    for d in (raw_dir, summary_dir, checks_dir):
        d.mkdir(parents=True, exist_ok=True)
    logs_dir = out_dir / 'logs'
    logs_dir.mkdir(parents=True, exist_ok=True)

    data_root = Path(args.data_root).resolve() if args.data_root else ROOT
    data_key = cfg.get('data', {}).get('main_csv', 'data/SMRTnet_main_repro.csv')
    split_key = cfg.get('data', {}).get('split_csv', 'data/splits/smrt_5fold_seed7.csv')
    data_path = (data_root / data_key).resolve() if not Path(data_key).is_absolute() else Path(data_key).resolve()
    split_path = (data_root / split_key).resolve() if not Path(split_key).is_absolute() else Path(split_key).resolve()

    # Quiet logging policy.
    log_cfg = cfg.get('logging', {})
    quiet_mode = str(log_cfg.get('mode', 'quiet')).lower() == 'quiet'
    rdkit_suppress = bool(log_cfg.get('rdkit_suppress', True))
    metrics_log = logs_dir / 'run_trace_e1_metrics.log'
    warning_log = logs_dir / 'run_trace_e1_warnings.log'
    if rdkit_suppress:
        try:
            from rdkit import RDLogger
            RDLogger.DisableLog('rdApp.*')
        except Exception as e:  # pragma: no cover
            warning_log.write_text(f'RDKit warning suppression failed: {e}\n', encoding='utf-8')

    t0 = time.time()
    set_global_seed(seed)
    df = load_data(data_path)
    split_df = load_split(split_path)
    validate_split(df, split_df, n_splits=n_splits)

    merged = df.merge(split_df, on='record_id', how='inner')

    hp = cfg.get('train', {}).get('locked_hparams', {})
    model_cfg = cfg.get('model', {})
    loss_cfg = cfg.get('loss', {})
    temp_cfg = cfg.get('temperature', {})
    weighting_cfg = cfg.get('weighting', {})
    train_cfg = TrainCfg(
        epochs=int(hp.get('epochs', 24)),
        batch_size=int(hp.get('batch_size', 64)),
        lr=float(hp.get('lr', 8e-4)),
        weight_decay=float(hp.get('weight_decay', 0.0)),
        rank_lambda=float(hp.get('rank_lambda', 0.1)),
        contrastive_temp=float(hp.get('contrastive_temp', 0.1)),
        early_stop_patience=int(hp.get('early_stop_patience', 4)),
        hidden=int(hp.get('hidden', 96)),
        dropout=float(hp.get('dropout', 0.05)),
        beta=float(weighting_cfg.get('beta', 0.35)),
        gamma=float(loss_cfg.get('gamma', 0.2)),
        lambda_supcon=float(loss_cfg.get('lambda_supcon', 0.2)),
        lambda_rank=float(loss_cfg.get('lambda_rank', hp.get('rank_lambda', 0.1))),
        encoder_type_drug=str(model_cfg.get('encoder_type_drug', 'mlp')),
        encoder_type_rna=str(model_cfg.get('encoder_type_rna', 'mlp')),
        temperature_mode=str(temp_cfg.get('mode', 'train_only')),
        tau_min=float(temp_cfg.get('tau_min', 0.5)),
        tau_max=float(temp_cfg.get('tau_max', 2.0)),
    )

    fold_rows, pred_rows = [], []
    for fold in range(1, n_splits + 1):
        if quiet_mode:
            with metrics_log.open('a', encoding='utf-8') as f:
                f.write(f'[fold {fold}/{n_splits}] start\n')
        tr_df = merged[merged['fold_id'] != fold].reset_index(drop=True)
        te_df = merged[merged['fold_id'] == fold].reset_index(drop=True)

        tr_pack, te_pack, _ = fit_transform_features(
            tr_df,
            te_df,
            drug_dim=int(cfg.get('feature', {}).get('drug_dim', 32)),
            rna_dim=int(cfg.get('feature', {}).get('rna_dim', 32)),
        )

        xtr = tr_pack['x64']
        xte = te_pack['x64']
        ytr = tr_df['label'].to_numpy(dtype='int32')
        yte = te_df['label'].to_numpy(dtype='int32')

        model = train_trace(xtr, ytr, cfg=train_cfg, seed=seed + fold)
        prob = predict_trace(model, xte)

        fold_rows.append({
            'fold': fold,
            'AUROC': safe_auroc(yte, prob),
            'AUPRC': safe_auprc(yte, prob),
            'ECE': ece_score(yte, prob),
            'Brier': brier(yte, prob),
            'n_train': int(len(tr_df)),
            'n_test': int(len(te_df)),
        })
        if quiet_mode:
            with metrics_log.open('a', encoding='utf-8') as f:
                f.write(
                    f"[fold {fold}/{n_splits}] done "
                    f"AUROC={fold_rows[-1]['AUROC']:.6f} "
                    f"AUPRC={fold_rows[-1]['AUPRC']:.6f} "
                    f"ECE={fold_rows[-1]['ECE']:.6f} "
                    f"Brier={fold_rows[-1]['Brier']:.6f}\n"
                )

        pred_rows.append(pd.DataFrame({
            'record_id': te_df['record_id'].astype(str),
            'fold': fold,
            'y_true': yte,
            'y_prob': prob,
        }))

    fold_df = pd.DataFrame(fold_rows).sort_values('fold').reset_index(drop=True)
    pred_df = pd.concat(pred_rows, ignore_index=True).sort_values(['fold', 'record_id']).reset_index(drop=True)

    summary_df = pd.DataFrame([{
        'model_name': 'TRACE',
        'AUROC_mean': float(fold_df['AUROC'].mean()),
        'AUROC_std': float(fold_df['AUROC'].std(ddof=0)),
        'AUPRC_mean': float(fold_df['AUPRC'].mean()),
        'AUPRC_std': float(fold_df['AUPRC'].std(ddof=0)),
        'ECE_mean': float(fold_df['ECE'].mean()),
        'ECE_std': float(fold_df['ECE'].std(ddof=0)),
        'Brier_mean': float(fold_df['Brier'].mean()),
        'Brier_std': float(fold_df['Brier'].std(ddof=0)),
    }])

    fold_path = raw_dir / 'trace_e1_raw.csv'
    sum_path = summary_dir / 'trace_e1_summary.csv'
    pred_path = raw_dir / 'trace_predictions.csv'
    man_path = checks_dir / 'run_manifest.json'

    fold_df.to_csv(fold_path, index=False)
    summary_df.to_csv(sum_path, index=False)
    pred_df.to_csv(pred_path, index=False)

    # Compare with golden summary under strict tolerance gate.
    golden_path = Path(args.golden)
    if not golden_path.is_absolute():
        golden_path = (ROOT / golden_path).resolve()
    diff_path = summary_dir / 'trace_e1_diff_vs_golden.csv'
    gate_path = checks_dir / 'gate_report.json'
    golden_diff_summary = {}
    if golden_path.exists():
        gold = pd.read_csv(golden_path).iloc[0]
        run = summary_df.iloc[0]
        cols = [
            'AUROC_mean', 'AUROC_std', 'AUPRC_mean', 'AUPRC_std',
            'ECE_mean', 'ECE_std', 'Brier_mean', 'Brier_std',
        ]
        rows = []
        for c in cols:
            rv = float(run[c])
            gv = float(gold[c])
            rows.append({
                'metric': c,
                'run_value': rv,
                'golden_value': gv,
                'abs_diff': abs(rv - gv),
                'within_tol': abs(rv - gv) <= float(args.tol),
            })
        diff_df = pd.DataFrame(rows)
        diff_df.to_csv(diff_path, index=False)
        golden_diff_summary = {
            'max_abs_diff_metric': str(diff_df.sort_values('abs_diff', ascending=False).iloc[0]['metric']),
            'max_abs_diff': float(diff_df['abs_diff'].max()),
            'all_within_tol': bool(diff_df['within_tol'].all()),
        }
        gate = {
            'tol': float(args.tol),
            'pass': bool(diff_df['within_tol'].all()),
            'blocking_metric': '' if bool(diff_df['within_tol'].all()) else str(
                diff_df.sort_values('abs_diff', ascending=False).iloc[0]['metric']
            ),
            'max_abs_diff': float(diff_df['abs_diff'].max()),
            'diff_csv': str(diff_path),
        }
    else:
        pd.DataFrame([{
            'metric': 'missing_golden',
            'run_value': '',
            'golden_value': '',
            'abs_diff': '',
            'within_tol': False,
        }]).to_csv(diff_path, index=False)
        gate = {
            'tol': float(args.tol),
            'pass': False,
            'blocking_metric': 'missing_golden',
            'max_abs_diff': None,
            'diff_csv': str(diff_path),
        }
        golden_diff_summary = {
            'max_abs_diff_metric': 'missing_golden',
            'max_abs_diff': None,
            'all_within_tol': False,
        }
    gate_path.write_text(json.dumps(gate, indent=2, ensure_ascii=False), encoding='utf-8')

    manifest = {
        'seed': seed,
        'n_splits': n_splits,
        'data_path': str(data_path),
        'split_path': str(split_path),
        'data_sha256': file_sha256(data_path),
        'split_sha256': file_sha256(split_path),
        'config_sha256': obj_sha256(cfg),
        'git_commit': git_commit_or_na(ROOT),
        'elapsed_sec': round(time.time() - t0, 4),
        'logging': {
            'mode': str(log_cfg.get('mode', 'quiet')),
            'rdkit_suppress': rdkit_suppress,
            'logs_dir': str(logs_dir),
            'metrics_log': str(metrics_log),
            'warnings_log': str(warning_log),
        },
        'trace_mechanism': {
            'encoder_type_drug': train_cfg.encoder_type_drug,
            'encoder_type_rna': train_cfg.encoder_type_rna,
            'temperature_mode': train_cfg.temperature_mode,
            'tau_min': train_cfg.tau_min,
            'tau_max': train_cfg.tau_max,
            'beta': train_cfg.beta,
            'gamma': train_cfg.gamma,
            'lambda_supcon': train_cfg.lambda_supcon,
            'lambda_rank': train_cfg.lambda_rank,
            'contrastive_temp': train_cfg.contrastive_temp,
        },
        'golden_diff_summary': golden_diff_summary,
        'outputs': {
            'raw': str(fold_path),
            'summary': str(sum_path),
            'predictions': str(pred_path),
            'diff_vs_golden': str(diff_path),
            'gate_report': str(gate_path),
        },
    }
    write_json(man_path, manifest)

    print(f'TRACE_E1_RAW={fold_path}')
    print(f'TRACE_E1_SUMMARY={sum_path}')
    print(f'RUN_MANIFEST={man_path}')


if __name__ == '__main__':
    os.environ['PYTHONHASHSEED'] = '7'
    main()

from __future__ import annotations

from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedKFold


REQ_COLS = ['record_id', 'smiles', 'rna_sequence', 'rna_secondary_structure', 'label']
SPLIT_PRIMARY_COLS = ['record_id']
SPLIT_FOLD_ALIASES = ['fold_id', 'fold']


def load_data(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise ValueError(
            f'data csv not found: {path}\n'
            'expected columns: record_id, smiles, rna_sequence, rna_secondary_structure, label'
        )
    df = pd.read_csv(path)
    missing = [c for c in REQ_COLS if c not in df.columns]
    if missing:
        raise ValueError(
            f'data csv missing columns: {missing}\n'
            f'expected columns: {REQ_COLS}'
        )
    out = df[REQ_COLS].copy()
    out['record_id'] = out['record_id'].astype(str)
    try:
        out['label'] = out['label'].astype(int)
    except Exception as exc:
        raise ValueError('column "label" must be integer-like (0/1)') from exc
    bad_labels = sorted(set(out['label'].unique().tolist()) - {0, 1})
    if bad_labels:
        raise ValueError(f'column "label" must be binary 0/1, got invalid values: {bad_labels[:10]}')
    return out


def generate_fixed_split(df: pd.DataFrame, n_splits: int, seed: int) -> pd.DataFrame:
    y = df['label'].to_numpy()
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    rows = []
    for fold, (_, te_idx) in enumerate(skf.split(df.index.to_numpy(), y), start=1):
        for i in te_idx:
            rows.append({'record_id': str(df.iloc[i]['record_id']), 'fold_id': int(fold)})
    s = pd.DataFrame(rows)
    return s.sort_values('record_id').reset_index(drop=True)


def load_split(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise ValueError(
            f'split csv not found: {path}\n'
            'expected columns: record_id and fold_id (or fold)'
        )
    s = pd.read_csv(path)
    missing_primary = [c for c in SPLIT_PRIMARY_COLS if c not in s.columns]
    if missing_primary:
        raise ValueError(
            f'split csv missing columns: {missing_primary}\n'
            'expected columns: record_id and fold_id (or fold)'
        )
    fold_col = None
    for c in SPLIT_FOLD_ALIASES:
        if c in s.columns:
            fold_col = c
            break
    if fold_col is None:
        raise ValueError('split csv missing fold column, expected one of: fold_id, fold')
    s['record_id'] = s['record_id'].astype(str)
    try:
        s['fold_id'] = s[fold_col].astype(int)
    except Exception as exc:
        raise ValueError(f'split column "{fold_col}" must be integer-like') from exc
    return s[['record_id', 'fold_id']]


def validate_split(df: pd.DataFrame, split_df: pd.DataFrame, n_splits: int) -> None:
    a = set(df['record_id'].astype(str).tolist())
    b = set(split_df['record_id'].astype(str).tolist())
    if a != b:
        miss_d = sorted(a - b)[:5]
        miss_s = sorted(b - a)[:5]
        raise ValueError(
            f'split/data record mismatch: miss_in_split={miss_d}, extra_in_split={miss_s}\n'
            'every record_id in data must appear exactly once in split'
        )
    counts = split_df.groupby('record_id').size()
    if not (counts == 1).all():
        raise ValueError('each record_id must map to exactly one fold')
    folds = sorted(split_df['fold_id'].unique().tolist())
    if folds != list(range(1, n_splits + 1)):
        raise ValueError(f'fold ids must be 1..{n_splits}, got {folds}')

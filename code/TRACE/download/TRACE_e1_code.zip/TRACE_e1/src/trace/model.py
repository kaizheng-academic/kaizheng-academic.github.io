from __future__ import annotations

import random
from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset


def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class EncoderFactory:
    """Factory for configurable encoder backends.

    The public E1 reproducibility path defaults to lightweight MLP encoders.
    Stub backends are intentionally shape-compatible so that the pipeline
    remains auditable and switchable without changing training interfaces.
    """

    @staticmethod
    def build(backend: str, in_dim: int, hidden: int, dropout: float) -> nn.Module:
        b = str(backend).lower()
        if b == 'mlp':
            return nn.Sequential(nn.Linear(in_dim, hidden), nn.ReLU(), nn.Dropout(dropout))
        if b == 'gnn_stub':
            # Placeholder backend to preserve the dual-encoder API in E1-only release.
            return nn.Sequential(nn.Linear(in_dim, hidden), nn.GELU(), nn.Dropout(dropout))
        if b == 'transformer_stub':
            # Placeholder backend to preserve the dual-encoder API in E1-only release.
            return nn.Sequential(
                nn.Linear(in_dim, hidden),
                nn.LayerNorm(hidden),
                nn.ReLU(),
                nn.Dropout(dropout),
            )
        raise ValueError(f'unsupported encoder backend: {backend}')


class TemperatureController(nn.Module):
    """Bounded learnable temperature scaling controller."""

    def __init__(self, mode: str = 'train_only', tau_min: float = 0.5, tau_max: float = 2.0) -> None:
        super().__init__()
        self.mode = str(mode).lower()
        self.tau_min = float(tau_min)
        self.tau_max = float(tau_max)
        self.tau = nn.Parameter(torch.tensor(1.0, dtype=torch.float32))

    def apply(self, logit: torch.Tensor, training: bool) -> torch.Tensor:
        if self.mode not in {'train_only', 'always', 'off'}:
            raise ValueError(f'unsupported temperature mode: {self.mode}')
        should_scale = self.mode == 'always' or (self.mode == 'train_only' and training)
        if not should_scale or self.mode == 'off':
            return logit
        t = torch.clamp(self.tau, self.tau_min, self.tau_max)
        return logit / t


class RankMarginLoss(nn.Module):
    def __init__(self, gamma: float = 0.2) -> None:
        super().__init__()
        self.gamma = float(gamma)

    def forward(self, logit: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        pos_mask = y > 0.5
        neg_mask = y < 0.5
        if pos_mask.sum() == 0 or neg_mask.sum() == 0:
            return torch.zeros((), dtype=logit.dtype, device=logit.device)
        margin_gap = logit[pos_mask].mean() - logit[neg_mask].mean()
        return torch.clamp(self.gamma - margin_gap, min=0.0)


def compute_weighted_bce(logit: torch.Tensor, y: torch.Tensor, beta: float) -> torch.Tensor:
    """Confidence-aware BCE for UaN negatives: w_neg = 1 - beta * sigmoid(logit)."""
    with torch.no_grad():
        conf = torch.sigmoid(logit).detach()
    w = torch.ones_like(y)
    neg_mask = y < 0.5
    w[neg_mask] = 1.0 - float(beta) * conf[neg_mask]
    bce = F.binary_cross_entropy_with_logits(logit, y, reduction='none')
    return (bce * w).mean()


class TRACENet(nn.Module):
    def __init__(
        self,
        in_dim: int = 64,
        hidden: int = 96,
        dropout: float = 0.05,
        encoder_type_drug: str = 'mlp',
        encoder_type_rna: str = 'mlp',
        temperature_mode: str = 'train_only',
        tau_min: float = 0.5,
        tau_max: float = 2.0,
    ) -> None:
        super().__init__()
        self.d_branch = EncoderFactory.build(encoder_type_drug, 32, hidden, dropout)
        self.r_branch = EncoderFactory.build(encoder_type_rna, 32, hidden, dropout)
        self.fuse = nn.Sequential(
            nn.Linear(hidden * 2 + 64, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, 1),
        )
        self.temp_ctl = TemperatureController(mode=temperature_mode, tau_min=tau_min, tau_max=tau_max)

    def forward(self, x64: torch.Tensor):
        xd = x64[:, :32]
        xr = x64[:, 32:64]
        hd = self.d_branch(xd)
        hr = self.r_branch(xr)
        inter = torch.cat([torch.abs(xd - xr), xd * xr], dim=1)
        h = torch.cat([hd, hr, inter], dim=1)
        logit = self.fuse(h).squeeze(-1)
        logit = self.temp_ctl.apply(logit, training=self.training)
        emb = torch.cat([hd, hr], dim=1)
        return logit, emb


def _supcon_loss(emb: torch.Tensor, y: torch.Tensor, temp: float = 0.1) -> torch.Tensor:
    z = F.normalize(emb, dim=1)
    sim = (z @ z.T) / temp
    yb = y.view(-1, 1)
    same = (yb == yb.T).float()
    eye = torch.eye(len(y), device=y.device)
    same = same - eye
    exp_sim = torch.exp(sim) * (1.0 - eye)
    log_prob = sim - torch.log(exp_sim.sum(dim=1, keepdim=True) + 1e-8)
    pos = (same * log_prob).sum(dim=1) / torch.clamp(same.sum(dim=1), min=1)
    return -pos.mean()


@dataclass
class TrainCfg:
    epochs: int = 24
    batch_size: int = 64
    lr: float = 8e-4
    weight_decay: float = 0.0
    rank_lambda: float = 0.1
    contrastive_temp: float = 0.1
    early_stop_patience: int = 4
    hidden: int = 96
    dropout: float = 0.05
    beta: float = 0.35
    gamma: float = 0.2
    lambda_supcon: float = 0.2
    lambda_rank: float = 0.1
    encoder_type_drug: str = 'mlp'
    encoder_type_rna: str = 'mlp'
    temperature_mode: str = 'train_only'
    tau_min: float = 0.5
    tau_max: float = 2.0


def train_trace(x_train: np.ndarray, y_train: np.ndarray, cfg: TrainCfg, seed: int) -> TRACENet:
    set_global_seed(seed)
    dev = torch.device('cpu')
    model = TRACENet(
        hidden=cfg.hidden,
        dropout=cfg.dropout,
        encoder_type_drug=cfg.encoder_type_drug,
        encoder_type_rna=cfg.encoder_type_rna,
        temperature_mode=cfg.temperature_mode,
        tau_min=cfg.tau_min,
        tau_max=cfg.tau_max,
    ).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    rank_loss = RankMarginLoss(gamma=cfg.gamma)

    x = torch.from_numpy(x_train).float()
    y = torch.from_numpy(y_train.astype(np.float32)).float()
    ds = TensorDataset(x, y)
    dl = DataLoader(ds, batch_size=cfg.batch_size, shuffle=True, num_workers=0)

    best_state = None
    best_loss = float('inf')
    bad = 0

    for _ in range(cfg.epochs):
        model.train()
        losses = []
        for bx, by in dl:
            bx = bx.to(dev)
            by = by.to(dev)
            logit, emb = model(bx)

            bce = compute_weighted_bce(logit, by, beta=cfg.beta)
            supcon = _supcon_loss(emb, by, temp=cfg.contrastive_temp)
            rank = rank_loss(logit, by)
            # Keep backward compatibility: if lambda_rank is not set, use rank_lambda.
            rank_w = cfg.lambda_rank if cfg.lambda_rank is not None else cfg.rank_lambda
            loss = bce + cfg.lambda_supcon * supcon + rank_w * rank

            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            losses.append(float(loss.detach().cpu()))

        mean_loss = float(np.mean(losses))
        if mean_loss < best_loss:
            best_loss = mean_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            bad = 0
        else:
            bad += 1
            if bad >= cfg.early_stop_patience:
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    model.eval()
    return model


def predict_trace(model: TRACENet, x_test: np.ndarray) -> np.ndarray:
    dev = torch.device('cpu')
    with torch.no_grad():
        x = torch.from_numpy(x_test).float().to(dev)
        logit, _ = model(x)
        p = torch.sigmoid(logit).cpu().numpy().astype(np.float64)
    return np.clip(p, 1e-7, 1 - 1e-7)

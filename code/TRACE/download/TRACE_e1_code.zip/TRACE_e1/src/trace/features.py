from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors, MACCSkeys
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler


@dataclass
class FeatureTransformer:
    drug_scaler: StandardScaler
    drug_pca: PCA
    rna_scaler: StandardScaler
    rna_pca: PCA


def _clean_seq(seq: str) -> str:
    s = re.sub(r'[^ACGTUacgtu]', '', str(seq)).upper().replace('T', 'U')
    return s if s else 'A'


def _sec_stats(seq: str, sec: str) -> np.ndarray:
    n = max(1, len(seq))
    s = str(sec)
    if len(s) != n:
        s = '.' * n
    opens = np.array([i for i, c in enumerate(s) if c == '('], dtype=np.int32)
    closes = np.array([i for i, c in enumerate(s) if c == ')'], dtype=np.int32)
    paired = min(len(opens), len(closes))
    pair_ratio = paired / float(n)
    loop_ratio = s.count('.') / float(n)
    stem_segments = len([x for x in s.split('.') if '(' in x or ')' in x])
    max_loop = max((len(x) for x in s.split('(') + s.split(')')), default=0)
    gc = (seq.count('G') + seq.count('C')) / float(n)
    au = (seq.count('A') + seq.count('U')) / float(n)
    entropy = 0.0
    for b in 'ACGU':
        p = seq.count(b) / float(n)
        if p > 0:
            entropy -= p * np.log2(p)
    return np.array([
        n, pair_ratio, loop_ratio, stem_segments, max_loop,
        gc, au, entropy,
        s.count('(') / float(n), s.count(')') / float(n),
        float(seq.startswith('G')), float(seq.endswith('G')),
    ], dtype=np.float32)


def _kmer3(seq: str) -> np.ndarray:
    alpha = 'ACGU'
    idx = {a + b + c: i for i, (a, b, c) in enumerate((x, y, z) for x in alpha for y in alpha for z in alpha)}
    v = np.zeros((64,), dtype=np.float32)
    if len(seq) < 3:
        return v
    for i in range(len(seq) - 2):
        k = seq[i:i + 3]
        if k in idx:
            v[idx[k]] += 1.0
    s = float(v.sum())
    if s > 0:
        v /= s
    return v


def _safe_mol(smiles: str):
    try:
        return Chem.MolFromSmiles(str(smiles))
    except Exception:
        return None


def _drug_feats(smiles: str) -> np.ndarray:
    mol = _safe_mol(smiles)
    if mol is None:
        return np.zeros((256 + 167 + 8,), dtype=np.float32)
    morgan = np.array(AllChem.GetMorganFingerprintAsBitVect(mol, radius=2, nBits=256), dtype=np.float32)
    maccs = np.array(MACCSkeys.GenMACCSKeys(mol), dtype=np.float32)
    phys = np.array([
        Descriptors.MolWt(mol),
        Descriptors.MolLogP(mol),
        Descriptors.TPSA(mol),
        Descriptors.NumHDonors(mol),
        Descriptors.NumHAcceptors(mol),
        Descriptors.NumRotatableBonds(mol),
        Descriptors.RingCount(mol),
        Descriptors.FractionCSP3(mol),
    ], dtype=np.float32)
    return np.concatenate([morgan, maccs, phys], axis=0)


def _rna_feats(seq: str, sec: str) -> np.ndarray:
    s = _clean_seq(seq)
    k3 = _kmer3(s)
    st = _sec_stats(s, sec)
    return np.concatenate([k3, st], axis=0)


def fit_transform_features(train_df: pd.DataFrame, test_df: pd.DataFrame, drug_dim: int = 32, rna_dim: int = 32):
    d_tr = np.stack([_drug_feats(x) for x in train_df['smiles'].astype(str)], axis=0)
    d_te = np.stack([_drug_feats(x) for x in test_df['smiles'].astype(str)], axis=0)

    r_tr = np.stack([_rna_feats(s, t) for s, t in zip(train_df['rna_sequence'].astype(str), train_df['rna_secondary_structure'].astype(str))], axis=0)
    r_te = np.stack([_rna_feats(s, t) for s, t in zip(test_df['rna_sequence'].astype(str), test_df['rna_secondary_structure'].astype(str))], axis=0)

    sd = StandardScaler()
    sr = StandardScaler()
    d_tr_s = sd.fit_transform(d_tr)
    d_te_s = sd.transform(d_te)
    r_tr_s = sr.fit_transform(r_tr)
    r_te_s = sr.transform(r_te)

    pdm = PCA(n_components=drug_dim, random_state=7)
    prm = PCA(n_components=rna_dim, random_state=7)
    d32_tr = pdm.fit_transform(d_tr_s).astype(np.float32)
    d32_te = pdm.transform(d_te_s).astype(np.float32)
    r32_tr = prm.fit_transform(r_tr_s).astype(np.float32)
    r32_te = prm.transform(r_te_s).astype(np.float32)

    x_tr = np.concatenate([d32_tr, r32_tr], axis=1).astype(np.float32)
    x_te = np.concatenate([d32_te, r32_te], axis=1).astype(np.float32)
    tr_pack = {'x64': x_tr, 'drug32': d32_tr, 'rna32': r32_tr}
    te_pack = {'x64': x_te, 'drug32': d32_te, 'rna32': r32_te}

    tfm = FeatureTransformer(drug_scaler=sd, drug_pca=pdm, rna_scaler=sr, rna_pca=prm)
    return tr_pack, te_pack, tfm

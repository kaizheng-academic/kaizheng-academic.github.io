# TRACE E1 Demo (TRACE-only)

This package contains a **TRACE-only** reproducible demo for E1.

## Included
- TRACE model/training/evaluation code
- One fixed E1 demo dataset (`data/SMRTnet_main_repro.csv`)
- One fixed 5-fold split (`data/splits/smrt_5fold_seed7.csv`)
- TRACE golden files for reproducibility checks (`golden/`)

## Not Included
- Any non-TRACE method code
- Any non-TRACE reference result tables

## Environment
```bash
conda activate DRI
```

## Run
```bash
python /Users/zack/Desktop/Code/trace-e1-demo-trace-only/scripts/run_trace_e1.py \
  --config /Users/zack/Desktop/Code/trace-e1-demo-trace-only/configs/trace_e1.yaml \
  --out /Users/zack/Desktop/Code/trace-e1-demo-trace-only/outputs/run_demo_001
```

## Repro Check
```bash
python /Users/zack/Desktop/Code/trace-e1-demo-trace-only/scripts/check_trace_repro.py \
  --run /Users/zack/Desktop/Code/trace-e1-demo-trace-only/outputs/run_demo_001 \
  --golden /Users/zack/Desktop/Code/trace-e1-demo-trace-only/golden/trace_e1_golden_summary.csv \
  --tol 1e-12
```

## Expected Outputs
- `outputs/run_demo_001/raw/trace_e1_raw.csv`
- `outputs/run_demo_001/raw/trace_predictions.csv`
- `outputs/run_demo_001/summary/trace_e1_summary.csv`
- `outputs/run_demo_001/summary/trace_e1_diff_vs_golden.csv`
- `outputs/run_demo_001/checks/run_manifest.json`
- `outputs/run_demo_001/checks/gate_report.json`
- `outputs/run_demo_001/checks/repro_check.json`
- `outputs/run_demo_001/logs/run_trace_e1_metrics.log`
- `outputs/run_demo_001/logs/run_trace_e1_warnings.log`

## Reproducibility Contract
- Seed: `7`
- Folds: `5`
- Tolerance: controlled by `--tol` in repro check
